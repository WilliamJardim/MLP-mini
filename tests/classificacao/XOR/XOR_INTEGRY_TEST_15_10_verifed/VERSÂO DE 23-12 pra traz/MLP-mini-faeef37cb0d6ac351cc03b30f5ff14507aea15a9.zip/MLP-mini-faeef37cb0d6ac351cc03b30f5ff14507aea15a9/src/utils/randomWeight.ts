// Função para inicializar pesos de forma aleatória
export default function randomWeight(): number {
    return Math.random() * 2 - 1; // Gera valores entre -1 e 1
}
interface HyperParameters{
    learningRate: number
}
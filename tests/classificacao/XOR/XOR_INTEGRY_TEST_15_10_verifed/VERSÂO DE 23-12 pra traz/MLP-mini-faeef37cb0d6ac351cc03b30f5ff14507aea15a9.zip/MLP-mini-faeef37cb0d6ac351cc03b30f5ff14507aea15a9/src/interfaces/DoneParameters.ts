interface DoneParameters{
    weights: number[][][],
    biases: number[][],
    layers: any[],
    generatedAt: number
}
